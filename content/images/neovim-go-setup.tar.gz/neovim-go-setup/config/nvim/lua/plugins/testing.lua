return {
  {
    "vim-test/vim-test",
    config = function()
      vim.g["test#strategy"] = "neovim"
      vim.g["test#neovim#term_position"] = "belowright"
      vim.g["test#neovim#start_normal"] = 1 -- Keep test window open
      vim.g["test#neovim#kill_previous"] = 1 -- Kill previous test before running new one
      
      -- Test keybindings
      vim.keymap.set("n", "<leader>tf", ":TestFile<CR>", { silent = true }) -- Run file tests
      vim.keymap.set("n", "<leader>ts", ":TestSuite<CR>", { silent = true }) -- Run all tests
      vim.keymap.set("n", "<leader>tl", ":TestLast<CR>", { silent = true }) -- Run last test
      vim.keymap.set("n", "<leader>tv", ":TestVisit<CR>", { silent = true }) -- Visit test file
      
      -- Navigate between test window and source
      vim.keymap.set("n", "<leader>to", function()
        -- Toggle between test window and source
        local wins = vim.api.nvim_list_wins()
        local current_win = vim.api.nvim_get_current_win()
        for _, win in ipairs(wins) do
          local buf = vim.api.nvim_win_get_buf(win)
          local buftype = vim.api.nvim_buf_get_option(buf, "buftype")
          if buftype == "terminal" and win ~= current_win then
            vim.api.nvim_set_current_win(win)
            return
          end
        end
        -- If no terminal window found, go to previous window
        vim.cmd("wincmd p")
      end, { silent = true, desc = "Toggle test window" })
      
      -- Jump to file:line under cursor (gF alternative for test output)
      vim.keymap.set("n", "<leader>tj", function()
        local line = vim.api.nvim_get_current_line()
        local cursor_pos = vim.api.nvim_win_get_cursor(0)
        local col = cursor_pos[2]
        local current_win = vim.api.nvim_get_current_win()
        
        -- Look for file:line pattern under cursor or in current line
        local patterns = {
          "([%w_/.-]+%.go):(%d+)",  -- filename.go:123
          "([%w_/.-]+):(%d+)",      -- general file:line
        }
        
        for _, pattern in ipairs(patterns) do
          for file, line_num in line:gmatch(pattern) do
            -- Check if cursor is roughly on this match
            local start_pos = line:find(file .. ":" .. line_num, 1, true)
            if start_pos and col >= start_pos - 1 and col <= start_pos + #file + #line_num then
              -- Find a non-terminal window to open the file in
              local target_win = nil
              local wins = vim.api.nvim_list_wins()
              
              for _, win in ipairs(wins) do
                if win ~= current_win then
                  local buf = vim.api.nvim_win_get_buf(win)
                  local buftype = vim.api.nvim_buf_get_option(buf, "buftype")
                  if buftype == "" then -- Normal buffer (not terminal)
                    target_win = win
                    break
                  end
                end
              end
              
              -- If no suitable window found, create a split
              if not target_win then
                vim.cmd("wincmd p") -- Go to previous window
                vim.cmd("split") -- Create horizontal split
                target_win = vim.api.nvim_get_current_win()
              else
                vim.api.nvim_set_current_win(target_win)
              end
              
              -- Open the file and go to line
              vim.cmd("edit " .. file)
              vim.cmd(":" .. line_num)
              vim.api.nvim_feedkeys("zz", "n", false) -- Center the line
              return
            end
          end
        end
        
        -- If no file:line found at cursor, try gF in previous window
        vim.cmd("wincmd p")
        vim.cmd("normal! gF")
      end, { silent = true, desc = "Jump to file:line in other window" })
      
      -- Custom test commands in dedicated window
      vim.keymap.set("n", "<leader>tc", function()
        -- Prompt for custom test command
        local cmd = vim.fn.input("Go test command: ", "go test -v ./...")
        if cmd and cmd ~= "" then
          -- Create/find terminal window
          vim.cmd("belowright split | terminal " .. cmd)
          vim.cmd("startinsert")
        end
      end, { silent = true, desc = "Run custom Go test command" })
      
      -- Quick custom test commands
      vim.keymap.set("n", "<leader>tcc", function()
        vim.cmd("belowright split | terminal go test -count=1 -v ./...")
      end, { silent = true, desc = "Run all tests with no cache" })
      
      vim.keymap.set("n", "<leader>tcr", function()
        vim.cmd("belowright split | terminal go test -race -v ./...")
      end, { silent = true, desc = "Run tests with race detection" })
      
      vim.keymap.set("n", "<leader>tcb", function()
        vim.cmd("belowright split | terminal go test -bench=. -v ./...")
      end, { silent = true, desc = "Run benchmark tests" })
    end,
  },
}