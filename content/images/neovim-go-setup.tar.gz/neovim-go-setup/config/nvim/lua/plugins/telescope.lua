return {
  {
    "nvim-telescope/telescope.nvim",
    tag = "0.1.8",
    dependencies = { "nvim-lua/plenary.nvim" },
    config = function()
      local telescope = require("telescope")
      local builtin = require("telescope.builtin")
      
      -- Configure telescope with shorter file paths
      telescope.setup({
        defaults = {
          path_display = { "filename_first" }, -- Show filename first, then path
          mappings = {
            i = {
              ["<C-c>"] = require("telescope.actions").close,
              ["<Esc>"] = require("telescope.actions").close,
            },
            n = {
              ["<Esc>"] = require("telescope.actions").close,
              ["q"] = require("telescope.actions").close,
            },
          },
        },
        pickers = {
          lsp_references = {
            path_display = { "smart" }, -- Smart path truncation
            fname_width = 40, -- Max width for filenames
          },
          lsp_implementations = {
            path_display = { "smart" },
            fname_width = 40,
          },
          lsp_definitions = {
            path_display = { "smart" },
            fname_width = 40,
          },
          lsp_type_definitions = {
            path_display = { "smart" },
            fname_width = 40,
          },
        },
      })
      
      vim.keymap.set("n", "<leader>ff", builtin.find_files, {})
      vim.keymap.set("n", "<leader>fg", builtin.live_grep, {})
      vim.keymap.set("n", "<leader>fb", builtin.buffers, {})
      vim.keymap.set("n", "<leader>fh", builtin.help_tags, {})
      vim.keymap.set("n", "<C-p>", builtin.find_files, {}) -- GoLand-like file finder
      
      -- LSP telescope integrations
      vim.keymap.set("n", "<leader>lr", builtin.lsp_references, {}) -- Find references
      vim.keymap.set("n", "<leader>li", builtin.lsp_implementations, {}) -- Find implementations
      vim.keymap.set("n", "<leader>ld", builtin.lsp_definitions, {}) -- Find definitions
      vim.keymap.set("n", "<leader>lt", builtin.lsp_type_definitions, {}) -- Find type definitions
      vim.keymap.set("n", "<leader>ls", builtin.lsp_document_symbols, {}) -- Document symbols
      vim.keymap.set("n", "<leader>lw", builtin.lsp_workspace_symbols, {}) -- Workspace symbols
    end,
  },
}