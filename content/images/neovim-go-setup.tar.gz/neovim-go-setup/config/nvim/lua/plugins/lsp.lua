return {
  {
    "neovim/nvim-lspconfig",
    dependencies = {
      "williamboman/mason.nvim",
      "williamboman/mason-lspconfig.nvim",
    },
    config = function()
      require("mason").setup()
      require("mason-lspconfig").setup({
        ensure_installed = { "gopls" },
      })

      local lspconfig = require("lspconfig")
      
      -- Configure gopls
      lspconfig.gopls.setup({
        capabilities = require('cmp_nvim_lsp').default_capabilities(),
        settings = {
          gopls = {
            analyses = {
              unusedparams = true,
            },
            staticcheck = true,
            gofumpt = true,
            codelenses = {
              gc_details = false,
              generate = true,
              regenerate_cgo = true,
              run_govulncheck = true,
              test = true,
              tidy = true,
              upgrade_dependency = true,
              vendor = true,
            },
            hints = {
              assignVariableTypes = false,
              compositeLiteralFields = false,
              compositeLiteralTypes = false,
              constantValues = false,
              functionTypeParameters = false,
              parameterNames = false,
              rangeVariableTypes = false,
            },
          },
        },
      })

      -- LSP keymaps (GoLand-like)
      vim.api.nvim_create_autocmd("LspAttach", {
        group = vim.api.nvim_create_augroup("UserLspConfig", {}),
        callback = function(ev)
          local opts = { buffer = ev.buf }
          vim.keymap.set("n", "gd", vim.lsp.buf.definition, opts) -- Go to definition
          vim.keymap.set("n", "gr", vim.lsp.buf.references, opts) -- Find references
          vim.keymap.set("n", "gi", vim.lsp.buf.implementation, opts) -- Go to implementation
          vim.keymap.set("n", "gt", vim.lsp.buf.type_definition, opts) -- Go to type definition
          vim.keymap.set("n", "<F12>", vim.lsp.buf.declaration, opts) -- Go to declaration
          vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename, opts) -- Rename
          vim.keymap.set("n", "<leader>ca", vim.lsp.buf.code_action, opts) -- Code actions
          vim.keymap.set("n", "K", vim.lsp.buf.hover, opts) -- Hover
          vim.keymap.set("n", "<C-k>", vim.lsp.buf.signature_help, opts) -- Signature help
          vim.keymap.set("n", "<leader>f", function()
            vim.lsp.buf.format { async = true }
          end, opts) -- Format
          
          -- Disable inlay hints by default
          vim.lsp.inlay_hint.enable(false, { bufnr = ev.buf })
          
          -- Toggle inlay hints
          vim.keymap.set("n", "<leader>ih", function()
            vim.lsp.inlay_hint.enable(not vim.lsp.inlay_hint.is_enabled({ bufnr = ev.buf }), { bufnr = ev.buf })
          end, opts) -- Toggle inlay hints
        end,
      })
    end,
  },
}