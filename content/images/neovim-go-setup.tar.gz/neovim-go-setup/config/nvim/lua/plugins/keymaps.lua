return {
  {
    "folke/which-key.nvim",
    event = "VeryLazy",
    config = function()
      vim.o.timeout = true
      vim.o.timeoutlen = 300
      require("which-key").setup()
      
      -- Additional GoLand-like keymaps
      local wk = require("which-key")
      
      -- Normal mode keymaps
      vim.keymap.set("n", "<C-s>", ":w<CR>", { silent = true }) -- Save file
      vim.keymap.set("n", "<C-z>", ":undo<CR>", { silent = true }) -- Undo
      vim.keymap.set("n", "<C-y>", ":redo<CR>", { silent = true }) -- Redo
      vim.keymap.set("n", "<C-d>", ":t.<CR>", { silent = true }) -- Duplicate line
      vim.keymap.set("n", "<C-/>", "gcc", { remap = true }) -- Comment line
      vim.keymap.set("v", "<C-/>", "gc", { remap = true }) -- Comment selection
      
      -- Debug keymaps
      vim.keymap.set("n", "<F9>", function() require("dap").toggle_breakpoint() end, { silent = true })
      vim.keymap.set("n", "<F5>", function() require("dap").continue() end, { silent = true })
      vim.keymap.set("n", "<F10>", function() require("dap").step_over() end, { silent = true })
      vim.keymap.set("n", "<F11>", function() require("dap").step_into() end, { silent = true })
      vim.keymap.set("n", "<S-F11>", function() require("dap").step_out() end, { silent = true })
      
      -- Jump list navigation (rebind Ctrl+o/i to Ctrl+[/])
      vim.keymap.set("n", "<C-[>", "<C-o>", { silent = true }) -- Go back
      vim.keymap.set("n", "<C-]>", "<C-i>", { silent = true }) -- Go forward
      
      -- LSP shortcuts (GoLand-like)
      vim.keymap.set("n", "<C-b>", function() require("telescope.builtin").lsp_definitions() end, { silent = true }) -- Go to definition
      
      -- Prevent ESC in normal mode from doing unexpected things
      vim.keymap.set("n", "<Esc>", "<Nop>", { silent = true }) -- Disable ESC in normal mode
      
      -- Terminal mode escape (alternative to Ctrl+\ Ctrl+n)
      vim.keymap.set("t", "<C-\\><C-e>", "<C-\\><C-n>", { silent = true }) -- Exit terminal mode with Ctrl+\ Ctrl+e
      vim.keymap.set("t", "<C-q>", "<C-\\><C-n>", { silent = true }) -- Exit terminal mode with Ctrl+q
      
      -- Window navigation (similar to GoLand split navigation)
      vim.keymap.set("n", "<C-h>", "<C-w>h", { silent = true })
      vim.keymap.set("n", "<C-j>", "<C-w>j", { silent = true })
      vim.keymap.set("n", "<C-k>", "<C-w>k", { silent = true })
      vim.keymap.set("n", "<C-l>", "<C-w>l", { silent = true })
      
      wk.add({
        { "<leader>g", group = "Go" },
        { "<leader>gt", ":GoTest<CR>", desc = "Go Test" },
        { "<leader>gr", ":GoRun<CR>", desc = "Go Run" },
        { "<leader>gb", ":GoBuild<CR>", desc = "Go Build" },
        { "<leader>gi", ":GoImport<CR>", desc = "Go Import" },
        { "<leader>gf", ":GoFmt<CR>", desc = "Go Format" },
        
        { "<leader>d", group = "Debug" },
        { "<leader>db", function() require("dap").toggle_breakpoint() end, desc = "Toggle Breakpoint" },
        { "<leader>dc", function() require("dap").continue() end, desc = "Continue" },
        { "<leader>di", function() require("dap").step_into() end, desc = "Step Into" },
        { "<leader>do", function() require("dap").step_over() end, desc = "Step Over" },
        { "<leader>dr", function() require("dap").repl.open() end, desc = "Open REPL" },
        
        { "<leader>t", group = "Test" },
        { "<leader>tn", ":TestNearest<CR>", desc = "Test Nearest" },
        { "<leader>tf", ":TestFile<CR>", desc = "Test File" },
        { "<leader>ts", ":TestSuite<CR>", desc = "Test Suite" },
        { "<leader>tl", ":TestLast<CR>", desc = "Test Last" },
        { "<leader>to", desc = "Toggle test window" },
        { "<leader>tj", desc = "Jump to file:line in other window" },
        { "<leader>tc", desc = "Custom test command" },
        { "<leader>tcc", desc = "Test all (no cache)" },
        { "<leader>tcr", desc = "Test with race detection" },
        { "<leader>tcb", desc = "Run benchmarks" },
        
        { "<leader>l", group = "LSP" },
        { "<leader>lr", function() require("telescope.builtin").lsp_references() end, desc = "References" },
        { "<leader>li", function() require("telescope.builtin").lsp_implementations() end, desc = "Implementations" },
        { "<leader>ld", function() require("telescope.builtin").lsp_definitions() end, desc = "Definitions" },
        { "<leader>lt", function() require("telescope.builtin").lsp_type_definitions() end, desc = "Type Definitions" },
        { "<leader>ls", function() require("telescope.builtin").lsp_document_symbols() end, desc = "Document Symbols" },
        { "<leader>lw", function() require("telescope.builtin").lsp_workspace_symbols() end, desc = "Workspace Symbols" },
        { "<leader>ih", desc = "Toggle inlay hints" },
      })
    end,
  },
}