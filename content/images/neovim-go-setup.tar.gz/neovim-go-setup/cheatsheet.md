# Neovim Go Development Cheatsheet

## Leader Key
**Leader**: `,` (comma)

## Basic Navigation
| Key | Action |
|-----|--------|
| `h` `j` `k` `l` | Move left/down/up/right |
| `w` | Move forward by word |
| `b` | Move backward by word |
| `0` | Move to beginning of line |
| `$` | Move to end of line |
| `gg` | Go to top of file |
| `G` | Go to bottom of file |
| `Ctrl+u` | Scroll up half page |
| `Ctrl+d` | Scroll down half page |
| `Ctrl+[` | Go back to previous location |
| `Ctrl+]` | Go forward to next location |

## File Navigation
| Key | Action |
|-----|--------|
| `,ff` | Find files (Telescope) |
| `,fg` | Live grep (search in files) |
| `,fb` | Find buffers |
| `Ctrl+p` | Quick file finder |
| `,e` | Toggle file tree |
| `Ctrl+1` | Toggle file tree (alternative) |

## LSP (Language Server) - Core
| Key | Action |
|-----|--------|
| `gd` / `Ctrl+b` | Go to definition |
| `gi` | Go to implementation |
| `gr` | Find references |
| `gt` | Go to type definition |
| `F12` | Go to declaration |
| `K` | Show hover information |
| `Ctrl+k` | Show signature help |
| `,rn` | Rename symbol |
| `,ca` | Code actions |
| `,f` | Format file |
| `,ih` | Toggle inlay hints (show/hide variable types) |

## LSP with Telescope (Better UI)
| Key | Action |
|-----|--------|
| `,lr` | Find references |
| `,li` | Find implementations |
| `,ld` | Find definitions |
| `,lt` | Find type definitions |
| `,ls` | Document symbols |
| `,lw` | Workspace symbols |

## Go-Specific Commands
| Key | Action |
|-----|--------|
| `,gt` | Run Go test |
| `,gr` | Run Go program |
| `,gb` | Build Go program |
| `,gi` | Add Go import |
| `,gf` | Format Go file |

## Testing
| Key | Action |
|-----|--------|
| `,tn` | Run nearest test |
| `,tf` | Run file tests |
| `,ts` | Run all tests |
| `,tl` | Run last test |
| `,tv` | Visit test file |
| `,to` | Toggle between test window and source |
| `,tj` | Jump to file:line in other window (keeps test window open) |

## Custom Test Commands
| Key | Action |
|-----|--------|
| `,tc` | Run custom Go test command (prompts for input) |
| `,tcc` | Run all tests with no cache (`go test -count=1 -v ./...`) |
| `,tcr` | Run tests with race detection (`go test -race -v ./...`) |
| `,tcb` | Run benchmark tests (`go test -bench=. -v ./...`) |

## Terminal
| Key | Action |
|-----|--------|
| `:terminal` | Open terminal in current window |
| `:split \| terminal` | Open terminal in horizontal split |
| `Ctrl+q` | Exit terminal mode to inspect output |
| `i` or `a` | Re-enter terminal mode |

### Test Window Navigation
- Test window stays open after running tests
- Use `,to` to jump between test output and source code
- In test window: use `/` to search for "FAIL" or specific errors
- **Place cursor on `filename.go:42` and press `,tj` to open file in other window**
- **Test window remains visible** - perfect for iterative debugging!
- Use `Ctrl+w` + arrow keys to navigate between windows
- Alternative: built-in `gF` also works for file:line jumps (but closes test window)

## Debugging
| Key | Action |
|-----|--------|
| `F9` | Toggle breakpoint |
| `F5` | Start/continue debugging |
| `F10` | Step over |
| `F11` | Step into |
| `Shift+F11` | Step out |
| `,db` | Toggle breakpoint |
| `,dc` | Continue |
| `,di` | Step into |
| `,do` | Step over |
| `,dr` | Open debug REPL |

## Editing
| Key | Action |
|-----|--------|
| `i` | Insert mode |
| `a` | Insert after cursor |
| `o` | New line below |
| `O` | New line above |
| `x` | Delete character |
| `dd` | Delete line |
| `yy` | Copy line |
| `p` | Paste |
| `u` | Undo |
| `Ctrl+r` | Redo |
| `Ctrl+s` | Save file |
| `Ctrl+d` | Duplicate line |
| `Ctrl+/` | Comment/uncomment line |

## Window Management
| Key | Action |
|-----|--------|
| `Ctrl+h` | Move to left window |
| `Ctrl+j` | Move to bottom window |
| `Ctrl+k` | Move to top window |
| `Ctrl+l` | Move to right window |
| `:split` | Horizontal split |
| `:vsplit` | Vertical split |
| `:q` | Close window |

## Search & Replace
| Key | Action |
|-----|--------|
| `/` | Search forward |
| `?` | Search backward |
| `n` | Next search result |
| `N` | Previous search result |
| `:%s/old/new/g` | Replace all occurrences |
| `:%s/old/new/gc` | Replace with confirmation |

## Auto-completion (nvim-cmp)
| Key | Action |
|-----|--------|
| `Tab` | Select next completion |
| `Shift+Tab` | Select previous completion |
| `Enter` | Accept completion |
| `Ctrl+Space` | Trigger completion |
| `Ctrl+e` | Abort completion |

## File Tree (nvim-tree)
| Key | Action |
|-----|--------|
| `Enter` | Open file/folder |
| `o` | Open file/folder |
| `a` | Create new file |
| `d` | Delete file |
| `r` | Rename file |
| `x` | Cut file |
| `c` | Copy file |
| `p` | Paste file |
| `R` | Refresh tree |

## Telescope
| Key | Action |
|-----|--------|
| `Ctrl+n` | Next item |
| `Ctrl+p` | Previous item |
| `Enter` | Select item |
| `Esc` | Close telescope |
| `Tab` | Toggle selection |
| `Ctrl+c` | Close telescope |

## Quick Tips
- Use `:help <command>` for detailed help on any command
- Use `:checkhealth` to verify your setup is working correctly
- Use `:Mason` to manage LSP servers and tools
- Use `:Lazy` to manage plugins
- Most commands work with counts (e.g., `3dd` deletes 3 lines)
- Visual mode: `v` for character selection, `V` for line selection
- To exit any mode, press `Esc`

## Common Go Workflow
1. Open project: `nvim .`
2. Find files: `,ff` or `Ctrl+p`
3. Navigate code: `gd`, `gi`, `gr`
4. Edit and format: `,f`
5. Run tests: `,tn` or `,tf`
6. Debug: `F9` to set breakpoints, `F5` to start
7. Save: `Ctrl+s` or `:w`