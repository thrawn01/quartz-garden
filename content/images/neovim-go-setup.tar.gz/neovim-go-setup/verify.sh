#!/bin/bash

# Verification script for Neovim Go setup

echo "🔍 Verifying Neovim Go Development Setup..."
echo "=============================================="

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

check_command() {
    if command -v "$1" &> /dev/null; then
        echo -e "${GREEN}✅ $1 found${NC}"
        if [ "$1" = "nvim" ]; then
            echo "   Version: $(nvim --version | head -n1)"
        elif [ "$1" = "go" ]; then
            echo "   Version: $(go version)"
        fi
    else
        echo -e "${RED}❌ $1 not found${NC}"
        return 1
    fi
}

check_file() {
    if [ -f "$1" ]; then
        echo -e "${GREEN}✅ $1 exists${NC}"
    else
        echo -e "${RED}❌ $1 missing${NC}"
        return 1
    fi
}

echo "Checking system tools..."
check_command nvim
check_command go
check_command gopls
check_command dlv
check_command rg

echo ""
echo "Checking Neovim configuration..."
check_file "$HOME/.config/nvim/init.lua"
check_file "$HOME/.config/nvim/lua/plugins/lsp.lua"
check_file "$HOME/.config/nvim/lua/plugins/telescope.lua"
check_file "$HOME/.config/nvim/lua/plugins/go.lua"

echo ""
echo "Checking shell aliases..."
if alias vim 2>/dev/null | grep -q nvim; then
    echo -e "${GREEN}✅ vim alias set to nvim${NC}"
else
    echo -e "${YELLOW}⚠️  vim alias not set (may need to reload shell)${NC}"
fi

echo ""
echo "Testing Neovim startup..."
if nvim --headless +q 2>/dev/null; then
    echo -e "${GREEN}✅ Neovim starts successfully${NC}"
else
    echo -e "${RED}❌ Neovim startup failed${NC}"
fi

echo ""
echo "=============================================="
echo "Verification complete!"
echo ""
echo "If you see any ❌ errors above, try:"
echo "1. Reload your shell: source ~/.bashrc"
echo "2. Re-run the install script: ./install.sh"
echo "3. Check the README.md for manual steps"