#!/bin/bash

# Neovim Go Development Setup - Linux Install Script
# This script sets up a complete Neovim Go development environment

set -e  # Exit on any error

echo "🚀 Starting Neovim Go Development Setup..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Detect Linux distribution
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
        VERSION=$VERSION_ID
    else
        log_error "Cannot detect Linux distribution"
        exit 1
    fi
    log_info "Detected: $PRETTY_NAME"
}

# Install system dependencies
install_system_deps() {
    log_info "Installing system dependencies..."
    
    case $DISTRO in
        "ubuntu"|"debian")
            sudo apt update
            sudo apt install -y curl git build-essential unzip ripgrep fd-find
            ;;
        "centos"|"rhel"|"fedora")
            if command -v dnf &> /dev/null; then
                sudo dnf install -y curl git gcc gcc-c++ make unzip ripgrep fd-find
            else
                sudo yum install -y curl git gcc gcc-c++ make unzip
                # Install ripgrep manually for older systems
                if ! command -v rg &> /dev/null; then
                    log_warning "Installing ripgrep manually..."
                    curl -LO https://github.com/BurntSushi/ripgrep/releases/download/13.0.0/ripgrep-13.0.0-x86_64-unknown-linux-musl.tar.gz
                    tar xzf ripgrep-13.0.0-x86_64-unknown-linux-musl.tar.gz
                    sudo cp ripgrep-13.0.0-x86_64-unknown-linux-musl/rg /usr/local/bin/
                    rm -rf ripgrep-13.0.0-x86_64-unknown-linux-musl*
                fi
            fi
            ;;
        "arch"|"manjaro")
            sudo pacman -S --needed curl git base-devel unzip ripgrep fd
            ;;
        *)
            log_warning "Unknown distribution. Please install manually: curl git build-essential unzip ripgrep fd"
            ;;
    esac
    
    log_success "System dependencies installed"
}

# Install Neovim
install_neovim() {
    log_info "Installing Neovim..."
    
    # Remove old neovim if exists
    if command -v nvim &> /dev/null; then
        log_warning "Neovim already installed, checking version..."
        NVIM_VERSION=$(nvim --version | head -n1 | awk '{print $2}')
        log_info "Current version: $NVIM_VERSION"
    fi
    
    # Download and install latest Neovim
    log_info "Downloading latest Neovim..."
    cd /tmp
    curl -LO https://github.com/neovim/neovim/releases/latest/download/nvim-linux64.tar.gz
    
    # Extract and install
    sudo rm -rf /opt/nvim-linux64
    sudo tar xzf nvim-linux64.tar.gz -C /opt/
    
    # Create symlink
    sudo ln -sf /opt/nvim-linux64/bin/nvim /usr/local/bin/nvim
    
    # Verify installation
    if nvim --version > /dev/null 2>&1; then
        NVIM_VERSION=$(nvim --version | head -n1 | awk '{print $2}')
        log_success "Neovim $NVIM_VERSION installed successfully"
    else
        log_error "Failed to install Neovim"
        exit 1
    fi
}

# Install Go
install_go() {
    if command -v go &> /dev/null; then
        GO_VERSION=$(go version | awk '{print $3}')
        log_info "Go already installed: $GO_VERSION"
        return
    fi
    
    log_info "Installing Go..."
    
    # Download latest Go
    cd /tmp
    GO_VERSION=$(curl -s https://golang.org/VERSION?m=text)
    curl -LO "https://golang.org/dl/${GO_VERSION}.linux-amd64.tar.gz"
    
    # Install Go
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf "${GO_VERSION}.linux-amd64.tar.gz"
    
    # Add to PATH if not already there
    if ! echo $PATH | grep -q "/usr/local/go/bin"; then
        echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
        echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.profile
        export PATH=$PATH:/usr/local/go/bin
    fi
    
    # Set GOPATH
    if [ -z "$GOPATH" ]; then
        echo 'export GOPATH=$HOME/go' >> ~/.bashrc
        echo 'export GOPATH=$HOME/go' >> ~/.profile
        echo 'export PATH=$PATH:$GOPATH/bin' >> ~/.bashrc
        echo 'export PATH=$PATH:$GOPATH/bin' >> ~/.profile
        export GOPATH=$HOME/go
        export PATH=$PATH:$GOPATH/bin
        mkdir -p $GOPATH/bin
    fi
    
    log_success "Go installed successfully"
}

# Install Go tools
install_go_tools() {
    log_info "Installing Go development tools..."
    
    # Ensure Go is in PATH
    export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin
    
    # Install essential Go tools
    go install golang.org/x/tools/gopls@latest
    go install golang.org/x/tools/cmd/goimports@latest
    go install github.com/go-delve/delve/cmd/dlv@latest
    
    log_success "Go tools installed"
}

# Setup Neovim configuration
setup_neovim_config() {
    log_info "Setting up Neovim configuration..."
    
    # Backup existing config if it exists
    if [ -d "$HOME/.config/nvim" ]; then
        log_warning "Backing up existing Neovim config..."
        mv "$HOME/.config/nvim" "$HOME/.config/nvim.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Create config directory
    mkdir -p "$HOME/.config"
    
    # Copy our configuration
    cp -r "$(dirname "$0")/config/nvim" "$HOME/.config/"
    
    log_success "Neovim configuration installed"
}

# Setup shell aliases
setup_shell_aliases() {
    log_info "Setting up shell aliases..."
    
    # Detect shell and add aliases
    if [ -n "$BASH_VERSION" ]; then
        SHELL_RC="$HOME/.bashrc"
    elif [ -n "$ZSH_VERSION" ]; then
        SHELL_RC="$HOME/.zshrc"
    else
        SHELL_RC="$HOME/.profile"
    fi
    
    # Add vim/vi aliases if not already present
    if ! grep -q "alias vim.*nvim" "$SHELL_RC" 2>/dev/null; then
        echo "" >> "$SHELL_RC"
        echo "# Neovim aliases" >> "$SHELL_RC"
        echo "alias vim='nvim'" >> "$SHELL_RC"
        echo "alias vi='nvim'" >> "$SHELL_RC"
        log_success "Shell aliases added to $SHELL_RC"
    else
        log_info "Shell aliases already exist"
    fi
}

# Install and setup plugins
setup_plugins() {
    log_info "Setting up Neovim plugins..."
    
    # Run Neovim headless to install plugins
    log_info "Installing plugins (this may take a few minutes)..."
    nvim --headless "+Lazy! sync" +qa
    
    log_success "Plugins installed successfully"
}

# Verify installation
verify_installation() {
    log_info "Verifying installation..."
    
    # Check Neovim
    if ! command -v nvim &> /dev/null; then
        log_error "Neovim not found in PATH"
        return 1
    fi
    
    # Check Go
    if ! command -v go &> /dev/null; then
        log_error "Go not found in PATH"
        return 1
    fi
    
    # Check Go tools
    if ! command -v gopls &> /dev/null; then
        log_warning "gopls not found in PATH, may need to reload shell"
    fi
    
    # Check config
    if [ ! -f "$HOME/.config/nvim/init.lua" ]; then
        log_error "Neovim configuration not found"
        return 1
    fi
    
    log_success "Installation verification complete"
}

# Main installation process
main() {
    echo "==============================================="
    echo "  Neovim Go Development Environment Setup"
    echo "==============================================="
    echo ""
    
    # Check if running as root
    if [ "$EUID" -eq 0 ]; then
        log_error "Please do not run this script as root"
        exit 1
    fi
    
    # Detect distribution
    detect_distro
    
    # Install everything
    install_system_deps
    install_neovim
    install_go
    install_go_tools
    setup_neovim_config
    setup_shell_aliases
    setup_plugins
    verify_installation
    
    echo ""
    echo "==============================================="
    log_success "Installation complete! 🎉"
    echo "==============================================="
    echo ""
    echo "Next steps:"
    echo "1. Reload your shell: source ~/.bashrc (or restart terminal)"
    echo "2. Open Neovim: nvim"
    echo "3. Open a Go project and start coding!"
    echo ""
    echo "Key bindings:"
    echo "  Leader key: , (comma)"
    echo "  ,ff - Find files"
    echo "  gd - Go to definition" 
    echo "  ,tn - Run nearest test"
    echo "  ,tc - Custom test command"
    echo "  Ctrl+q - Exit terminal mode"
    echo ""
    echo "For full documentation, see: README.md"
    echo ""
}

# Run main function
main "$@"