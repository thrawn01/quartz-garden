# Neovim Go Development Setup

This package contains a complete Neovim configuration optimized for Go development, similar to GoLand with vi bindings.

## Quick Install

```bash
chmod +x install.sh
./install.sh
```

## What's Included

- **Neovim 0.11+** with Go LSP (gopls)
- **Lazy.nvim** package manager
- **Telescope** fuzzy finder with smart file paths
- **nvim-tree** file explorer
- **Go debugging** with delve integration
- **Testing framework** with custom test commands
- **Auto-completion** with nvim-cmp
- **Treesitter** syntax highlighting
- **GoLand-like keybindings**

## Key Features

### Navigation
- `gd` / `Ctrl+b` - Go to definition
- `gi` - Go to implementation  
- `gr` - Find references
- `Ctrl+[` - Go back to previous location
- `Ctrl+]` - Go forward to next location

### Testing  
- `,tn` - Run nearest test
- `,tc` - Custom test command (prompts for input)
- `,tcc` - Run all tests (no cache)
- `,tcr` - Run tests with race detection
- `,tj` - Jump to file:line from test output

### File Management
- `,ff` - Find files
- `,fg` - Live grep (search in files)
- `,e` - Toggle file tree
- `Ctrl+p` - Quick file finder

### Terminal
- `Ctrl+q` - Exit terminal mode to inspect output
- `:terminal` - Open terminal in current window

### LSP Features
- `,rn` - Rename symbol
- `,ca` - Code actions
- `,f` - Format file
- `,ih` - Toggle inlay hints (type annotations)

## Leader Key
- Leader key is set to `,` (comma)

## Post-Install

1. Open Neovim: `nvim`
2. Let plugins install automatically
3. Restart Neovim when installation completes
4. Open a Go project and enjoy!

## Requirements
- Linux system with package manager (apt/yum/dnf)
- Git
- Curl
- Internet connection for downloading tools